package com.example.pedidolanche;

import java.io.StringBufferInputStream;

public class Pedido {
    String codigo;
    String nome;
    String bebida;
    String lanche;
    String quantidade;

    @Override
    public String toString() {

        return codigo+'-'+nome+'-'+bebida+'-'+lanche+'-'+quantidade;
     /*  return "Pedido: {" +
                "codigo='" + codigo + '\'' +
              ", nome='" + nome + '\'' +
                ", bebida='" + bebida + '\'' +
                ", lanche='" + lanche + '\'' +
                ", quantidade='" + quantidade + '\'' +
                '}';

      */
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getBebida() {
        return bebida;
    }

    public void setBebida(String bebida) {
        this.bebida = bebida;
    }

    public String getLanche() {
        return lanche;
    }

    public void setLanche(String lanche) {
        this.lanche = lanche;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String quantidade) {
        this.quantidade = quantidade;
    }
}
