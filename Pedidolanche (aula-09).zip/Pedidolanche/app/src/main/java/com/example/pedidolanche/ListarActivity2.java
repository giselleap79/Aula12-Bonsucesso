package com.example.pedidolanche;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AlertDialogLayout;
import androidx.appcompat.widget.Toolbar;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListarActivity2 extends AppCompatActivity {

private EditText xeditpalavra;
private ListView xlistadepedidos;
private FirebaseDatabase xdatabase;
private DatabaseReference xreference;

private List<Pedido> listpedido = new ArrayList<Pedido>();
private ArrayAdapter<Pedido> arrayAdapterPedido;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar2);

        iniciarcomponentes();
        iniciarfirebase();
        eventoedit();

    }

    private void iniciarfirebase() {
        FirebaseApp.initializeApp(ListarActivity2.this);
        xdatabase=FirebaseDatabase.getInstance();
        xreference=xdatabase.getReference();
    }
    private void iniciarcomponentes(){
        xeditpalavra=(EditText) findViewById(R.id.editpalavra);
        xlistadepedidos = (ListView) findViewById(R.id.listadepedidos);
    }


    private void eventoedit() {
        xeditpalavra.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String palavra= xeditpalavra.getText().toString().trim();
                pesquisar(palavra);
            }
        });

    }

    private void pesquisar(String palavra) {
        Query query;
        if (palavra.equals("")){
            query=xreference.child("Pedidos").orderByChild("nome");
        }else{
            query=xreference.child("Pedidos").orderByChild("nome").startAt(palavra).endAt(palavra+"\uf8ff");

        }


        listpedido.clear();

        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot objSnapshot:dataSnapshot.getChildren()){
                    Pedido p= objSnapshot.getValue(Pedido.class);
                    listpedido.add(p);
                }
                arrayAdapterPedido = new ArrayAdapter<Pedido>(ListarActivity2.this, android.R.layout.simple_list_item_1,listpedido);
                xlistadepedidos.setAdapter(arrayAdapterPedido);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        pesquisar("");
    }
}