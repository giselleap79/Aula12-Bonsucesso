package com.example.pedidolanche;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    private FirebaseDatabase database;
    private DatabaseReference reference;
    EditText xcodigo, xnome, xbebida, xlanche, xquantidade;
    Button xbtnconsultar, xbtnatender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        xcodigo = findViewById(R.id.editcodigo);
        xnome = findViewById(R.id.editnome);
        xbebida = findViewById(R.id.editbebida);
        xlanche = findViewById(R.id.editlanche);
        xquantidade = findViewById(R.id.editquantidade);
        xbtnconsultar = (Button) findViewById(R.id.button2);
        xbtnatender = (Button) findViewById(R.id.button3);


        iniciarfirebase();
    }

    private void iniciarfirebase() {
        FirebaseApp.initializeApp(this);
        database = FirebaseDatabase.getInstance();
        database.setPersistenceEnabled(true);
        reference = database.getReference();
    }

    public void enviarpedido(View view) {
        String ycodigo = xcodigo.getText().toString();
        String ynome = xnome.getText().toString();
        String ybebida = xbebida.getText().toString();
        String ylanche = xlanche.getText().toString();
        String yquantidade = xquantidade.getText().toString();

        Pedido pedido = new Pedido();
        pedido.setCodigo(ycodigo);
        pedido.setNome(ynome);
        pedido.setBebida(ybebida);
        pedido.setLanche(ylanche);
        pedido.setQuantidade(yquantidade);

        reference.child("Pedidos").child(pedido.getCodigo()).setValue(pedido);
        Toast.makeText(MainActivity.this, "Pedido Enviado", Toast.LENGTH_LONG).show();

      limparedit();

    }

    private void limparedit() {
        xcodigo.setText("");
        xnome.setText("");
        xbebida.setText("");
        xlanche.setText("");
        xquantidade.setText("");

    }


    public void consultar(View view) {
        xbtnconsultar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view1){
                Intent it=new Intent(MainActivity.this, ListarActivity2.class);
                startActivity(it);
            }
        });

    }

public void atender(View view){

    xbtnatender.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view1) {
            Intent it = new Intent(MainActivity.this, AtenderActivity2.class);
            startActivity(it);

        }
    });
}
    public void sair(){

        finish();

        // Para isso retire o System.exit(0); e substitua o finish() por finishAffinity()
    }

}